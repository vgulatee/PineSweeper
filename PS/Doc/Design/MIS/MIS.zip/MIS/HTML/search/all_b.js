var searchData=
[
  ['thememanager',['themeManager',['../class_controller_1_1_game_manager.html#af90634b6c5977fc9a2230b7ee86bbe27',1,'Controller::GameManager']]]
];
