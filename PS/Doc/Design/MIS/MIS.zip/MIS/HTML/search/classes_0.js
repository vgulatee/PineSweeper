var searchData=
[
  ['boardpanel',['boardPanel',['../class_view_1_1board_panel.html',1,'View']]]
];
