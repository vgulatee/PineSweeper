var searchData=
[
  ['windowframe',['windowFrame',['../class_view_1_1window_frame.html#a45fc046a64ba6c78e32a97287f4baccb',1,'View::windowFrame']]]
];
