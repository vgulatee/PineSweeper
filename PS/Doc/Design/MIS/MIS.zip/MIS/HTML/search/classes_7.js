var searchData=
[
  ['windowframe',['windowFrame',['../class_view_1_1window_frame.html',1,'View']]]
];
