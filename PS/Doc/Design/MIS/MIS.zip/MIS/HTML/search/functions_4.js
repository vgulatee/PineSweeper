var searchData=
[
  ['gamemanager',['GameManager',['../class_controller_1_1_game_manager.html#aa7948e9c3486354cf507b39935bad0fa',1,'Controller::GameManager']]],
  ['getbutton',['getButton',['../class_model_1_1_cell.html#af6d9ce37437a06d27a3fb341d50000f6',1,'Model::Cell']]],
  ['getdig',['getDig',['../class_model_1_1_cell.html#ab22fcc72211f7f1e55cd3ea1c1a25ccc',1,'Model::Cell']]],
  ['getindex',['getIndex',['../class_model_1_1_cell.html#a2015d78d67e7e931670d9bee30ace0ea',1,'Model::Cell']]],
  ['getmark',['getMark',['../class_model_1_1_cell.html#a1a0a4027773297a468c5ef8c6772d1ba',1,'Model::Cell']]],
  ['getplot',['getPlot',['../class_model_1_1_cell.html#a30f69510aaeecb88103141d1b48a6472',1,'Model::Cell']]],
  ['getunderneath',['getUnderneath',['../class_model_1_1_cell.html#af37ab2fed7c7d9174ef178473708ea1e',1,'Model::Cell']]],
  ['gridbutton',['gridButton',['../class_view_1_1grid_button.html#afc9cb5a8a2bae8a074188e372a4f09cc',1,'View::gridButton']]]
];
