var searchData=
[
  ['paintcomponent',['paintComponent',['../class_view_1_1board_panel.html#a05483adc7de653c77fac5f6027f521b0',1,'View.boardPanel.paintComponent()'],['../class_view_1_1grid_button.html#a04b62069aa8d6491d2335770e39fb846',1,'View.gridButton.paintComponent()'],['../class_view_1_1smile_button.html#ae44b1e646643eb3f77737aa040950805',1,'View.smileButton.paintComponent()']]],
  ['pausebutton',['pauseButton',['../class_view_1_1pause_button.html',1,'View']]],
  ['pausecontroller',['pauseController',['../class_controller_1_1pause_controller.html',1,'Controller']]],
  ['plotgenerater',['plotGenerater',['../class_model_1_1_j_sweep_game_control.html#a88c97dd3e193611e006c280914ed313d',1,'Model::JSweepGameControl']]],
  ['prefmanager',['prefManager',['../class_controller_1_1_game_manager.html#a09da58eee9f602d93eea7e7f6809f5fe',1,'Controller::GameManager']]]
];
