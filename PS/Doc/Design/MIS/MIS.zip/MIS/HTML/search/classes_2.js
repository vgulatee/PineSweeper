var searchData=
[
  ['gameinfo',['gameInfo',['../class_view_1_1game_info.html',1,'View']]],
  ['gamemanager',['GameManager',['../class_controller_1_1_game_manager.html',1,'Controller']]],
  ['gridbutton',['gridButton',['../class_view_1_1grid_button.html',1,'View']]]
];
