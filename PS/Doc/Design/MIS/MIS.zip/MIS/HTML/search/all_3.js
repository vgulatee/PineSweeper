var searchData=
[
  ['flagspace',['flagSpace',['../class_model_1_1_cell.html#a94d71183e8fc9eafa5c648473843f5c4',1,'Model::Cell']]],
  ['funeral',['funeral',['../class_view_1_1smile_button.html#a68ab8a4dc7f1c830eb59a219a1df96b1',1,'View::smileButton']]]
];
