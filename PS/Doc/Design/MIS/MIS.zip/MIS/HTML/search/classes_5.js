var searchData=
[
  ['pausebutton',['pauseButton',['../class_view_1_1pause_button.html',1,'View']]],
  ['pausecontroller',['pauseController',['../class_controller_1_1pause_controller.html',1,'Controller']]]
];
